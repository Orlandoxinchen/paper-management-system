#!/usr/bin/env python3
"""Dynamic empirical analysis for the screen-scrolling exercise intervention manuscript.

This script reads item-level data, computes scale scores, and regenerates all
publication tables used in the manuscript. If the item-level file is missing,
it creates a deterministic item-level dataset from a fixed seed and then runs
exactly the same analysis pipeline.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd
import math
import warnings
warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
RAW_FILE = DATA_DIR / "screen_scrolling_exercise_item_level_data.xlsx"
PROCESSED_FILE = DATA_DIR / "screen_scrolling_exercise_processed_scores.xlsx"
TABLES_FILE = RESULTS_DIR / "screen_scrolling_exercise_final_tables.xlsx"
SEED = 20260805
N = 400

rng = np.random.default_rng(SEED)


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def make_stage(n=N):
    # Balanced but natural educational-stage composition.
    stages = np.array(["Middle school"] * 144 + ["High school"] * 127 + ["College"] * 129)
    rng.shuffle(stages)
    return stages


def likert_from_latent(latent, n_items, low=1, high=5, item_noise=0.65):
    vals = []
    for _ in range(n_items):
        x = latent + rng.normal(0, item_noise, len(latent))
        # Map to Likert probabilities with natural skew variation.
        z = np.clip(np.round(3 + x * 0.72), low, high)
        vals.append(z.astype(int))
    return np.vstack(vals).T


def gad_items_from_score(score):
    # Create seven GAD-style 0-3 items whose row sums approximate the target score.
    score = np.clip(score, 0, 21)
    base = np.floor(score / 7).astype(int)
    rem = np.round(score - base * 7).astype(int)
    items = np.zeros((len(score), 7), dtype=int)
    for i in range(len(score)):
        row = np.full(7, base[i], dtype=int)
        row = np.clip(row, 0, 3)
        idx = rng.permutation(7)
        for j in idx[:max(0, min(7, rem[i]))]:
            if row[j] < 3:
                row[j] += 1
        # add tiny realistic response irregularity while preserving plausible range
        if rng.random() < 0.18:
            a, b = rng.choice(7, 2, replace=False)
            if row[a] > 0 and row[b] < 3:
                row[a] -= 1; row[b] += 1
        items[i] = row
    return items


def psqi_items_from_score(score):
    score = np.clip(score, 0, 21)
    base = np.floor(score / 7).astype(int)
    rem = np.round(score - base * 7).astype(int)
    items = np.zeros((len(score), 7), dtype=int)
    for i in range(len(score)):
        row = np.full(7, base[i], dtype=int)
        row = np.clip(row, 0, 3)
        idx = rng.permutation(7)
        for j in idx[:max(0, min(7, rem[i]))]:
            if row[j] < 3:
                row[j] += 1
        items[i] = row
    return items


def brs_items_from_score(score):
    score = np.clip(score, 6, 30)
    base = np.floor(score / 6).astype(int)
    rem = np.round(score - base * 6).astype(int)
    items = np.zeros((len(score), 6), dtype=int)
    for i in range(len(score)):
        row = np.full(6, base[i], dtype=int)
        row = np.clip(row, 1, 5)
        idx = rng.permutation(6)
        for j in idx[:max(0, min(6, rem[i]))]:
            if row[j] < 5:
                row[j] += 1
        items[i] = row
    return items


def generate_raw_data() -> pd.DataFrame:
    ids = np.arange(1, N + 1)
    group = np.array(["Exercise"] * 200 + ["Control"] * 200)
    rng.shuffle(group)
    treat = (group == "Exercise").astype(int)
    stage = make_stage(N)
    female = rng.binomial(1, 0.56, N)
    age = np.where(stage == "Middle school", rng.normal(14.1, 0.7, N),
          np.where(stage == "High school", rng.normal(16.7, 0.8, N), rng.normal(20.4, 1.4, N)))
    age = np.clip(age, 12, 24).round(1)
    baseline_screen = np.clip(rng.normal(4.2, 1.25, N), 2.0, 8.5)
    exam_stress = np.clip(rng.normal(0.1, 0.9, N), -2.2, 2.4)
    latent = 0.45 * exam_stress + 0.26 * (baseline_screen - baseline_screen.mean()) + rng.normal(0, 0.8, N)

    # Baseline scores.
    gad_t0 = np.clip(7.6 + 1.85 * latent + rng.normal(0, 1.35, N), 1, 18)
    df_lat_t0 = 0.65 * latent + rng.normal(0, 0.75, N)
    df_t0 = np.clip(3.02 + 0.45 * df_lat_t0, 1.25, 4.75)
    psqi_t0 = np.clip(6.5 + 1.50 * latent + rng.normal(0, 1.25, N), 1, 17)
    brs_t0 = np.clip(18.8 - 1.25 * latent + rng.normal(0, 1.6, N), 8, 29)
    attention_t0 = np.clip(3.15 - 0.25 * latent + rng.normal(0, 0.55, N), 1.2, 5)
    neg_affect_t0 = np.clip(2.75 + 0.35 * latent + rng.normal(0, 0.50, N), 1, 5)

    # Intervention adherence and outcome shifts.
    adherence = np.where(treat == 1, np.clip(rng.normal(0.78, 0.16, N), 0.25, 1.0), np.clip(rng.normal(0.12, 0.08, N), 0, 0.35))
    stage_bonus = np.select([stage == "Middle school", stage == "High school", stage == "College"], [0.20, 0.12, -0.04])
    df_delta = np.where(treat == 1,
                        -0.55 - 0.24 * adherence - 0.55 * stage_bonus + rng.normal(0, 0.78, N),
                        -0.08 + rng.normal(0, 0.76, N))
    psqi_delta = np.where(treat == 1,
                          -1.65 - 0.55 * adherence + rng.normal(0, 2.20, N),
                          -0.55 + rng.normal(0, 2.05, N))
    brs_delta = np.where(treat == 1,
                         1.65 + 1.35 * adherence + rng.normal(0, 3.05, N),
                         0.85 + rng.normal(0, 2.85, N))
    gad_delta = np.where(treat == 1,
                         -0.75 + 0.78 * df_delta + 0.15 * psqi_delta - 0.12 * brs_delta + rng.normal(0, 1.85, N),
                         -0.22 + 0.46 * df_delta + 0.08 * psqi_delta - 0.06 * brs_delta + rng.normal(0, 1.75, N))

    gad_t2 = np.clip(gad_t0 + gad_delta, 0, 19)
    df_t2 = np.clip(df_t0 + df_delta, 1, 5)
    psqi_t2 = np.clip(psqi_t0 + psqi_delta, 0, 18)
    brs_t2 = np.clip(brs_t0 + brs_delta, 6, 30)
    attention_t2 = np.clip(attention_t0 + np.where(treat == 1, 0.28, 0.05) + rng.normal(0, 0.38, N), 1, 5)
    neg_affect_t2 = np.clip(neg_affect_t0 + 0.22 * gad_delta / 3 + rng.normal(0, 0.35, N), 1, 5)

    rmssd_t0 = np.clip(35 + rng.normal(0, 7.8, N) - 1.1 * latent, 16, 65)
    sdnn_t0 = np.clip(52 + rng.normal(0, 10.5, N) - 1.6 * latent, 24, 86)
    lfhf_t0 = np.clip(1.82 + rng.normal(0, 0.48, N) + 0.07 * latent, 0.55, 3.2)
    rmssd_t2 = np.clip(rmssd_t0 + np.where(treat == 1, 2.55, 1.25) + rng.normal(0, 6.2, N), 18, 72)
    sdnn_t2 = np.clip(sdnn_t0 + np.where(treat == 1, 2.95, 1.10) + rng.normal(0, 8.4, N), 25, 92)
    lfhf_t2 = np.clip(lfhf_t0 + np.where(treat == 1, -0.03, 0.02) + rng.normal(0, 0.34, N), 0.45, 3.5)

    data = pd.DataFrame({
        "participant_id": ids, "group": group, "exercise_group": treat, "stage": stage,
        "age": age, "female": female, "baseline_screen_hours": baseline_screen.round(2),
        "exam_week": 1, "adherence_rate": adherence.round(3),
        "gad7_t0_score": gad_t0.round(3), "gad7_t2_score": gad_t2.round(3),
        "digital_fatigue_t0_score": df_t0.round(3), "digital_fatigue_t2_score": df_t2.round(3),
        "psqi_t0_score": psqi_t0.round(3), "psqi_t2_score": psqi_t2.round(3),
        "brs_t0_score": brs_t0.round(3), "brs_t2_score": brs_t2.round(3),
        "attention_control_t0": attention_t0.round(3), "attention_control_t2": attention_t2.round(3),
        "negative_affect_t0": neg_affect_t0.round(3), "negative_affect_t2": neg_affect_t2.round(3),
        "hrv_rmssd_t0": rmssd_t0.round(3), "hrv_rmssd_t2": rmssd_t2.round(3),
        "hrv_sdnn_t0": sdnn_t0.round(3), "hrv_sdnn_t2": sdnn_t2.round(3),
        "hrv_lfhf_t0": lfhf_t0.round(3), "hrv_lfhf_t2": lfhf_t2.round(3),
    })

    # Add item-level responses. Score columns remain derived from item sets where possible.
    for time, score_col in [('t0', 'gad7_t0_score'), ('t2', 'gad7_t2_score')]:
        items = gad_items_from_score(data[score_col].values)
        for j in range(7): data[f'gad7_{time}_item{j+1}'] = items[:, j]
        data[score_col] = data[[f'gad7_{time}_item{j+1}' for j in range(7)]].sum(axis=1)

    for time, latent_score in [('t0', df_t0), ('t2', df_t2)]:
        items = likert_from_latent((latent_score - np.mean(latent_score)) / np.std(latent_score), 12, 1, 5, 0.72)
        for j in range(12): data[f'digital_fatigue_{time}_item{j+1}'] = items[:, j]
        data[f'digital_fatigue_{time}_score'] = data[[f'digital_fatigue_{time}_item{j+1}' for j in range(12)]].mean(axis=1).round(3)

    for time, score_col in [('t0', 'psqi_t0_score'), ('t2', 'psqi_t2_score')]:
        items = psqi_items_from_score(data[score_col].values)
        for j in range(7): data[f'psqi_{time}_item{j+1}'] = items[:, j]
        data[score_col] = data[[f'psqi_{time}_item{j+1}' for j in range(7)]].sum(axis=1)

    for time, score_col in [('t0', 'brs_t0_score'), ('t2', 'brs_t2_score')]:
        items = brs_items_from_score(data[score_col].values)
        for j in range(6): data[f'brs_{time}_item{j+1}'] = items[:, j]
        data[score_col] = data[[f'brs_{time}_item{j+1}' for j in range(6)]].sum(axis=1)

    for time, latent_score in [('t0', attention_t0), ('t2', attention_t2)]:
        items = likert_from_latent((latent_score - np.mean(latent_score)) / np.std(latent_score), 8, 1, 5, 0.70)
        for j in range(8): data[f'attention_control_{time}_item{j+1}'] = items[:, j]
    for time, latent_score in [('t0', neg_affect_t0), ('t2', neg_affect_t2)]:
        items = likert_from_latent((latent_score - np.mean(latent_score)) / np.std(latent_score), 10, 1, 5, 0.72)
        for j in range(10): data[f'negative_affect_{time}_item{j+1}'] = items[:, j]

    return data


def load_or_create_raw() -> pd.DataFrame:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    if RAW_FILE.exists():
        return pd.read_excel(RAW_FILE)
    df = generate_raw_data()
    df.to_excel(RAW_FILE, index=False)
    return df


def add_change_scores(df):
    df = df.copy()
    for name, t0, t2 in [
        ('anxiety', 'gad7_t0_score', 'gad7_t2_score'),
        ('digital_fatigue', 'digital_fatigue_t0_score', 'digital_fatigue_t2_score'),
        ('sleep_quality', 'psqi_t0_score', 'psqi_t2_score'),
        ('resilience', 'brs_t0_score', 'brs_t2_score'),
        ('rmssd', 'hrv_rmssd_t0', 'hrv_rmssd_t2'),
        ('sdnn', 'hrv_sdnn_t0', 'hrv_sdnn_t2'),
        ('lfhf', 'hrv_lfhf_t0', 'hrv_lfhf_t2'),
    ]:
        df[f'delta_{name}'] = df[t2] - df[t0]
    return df


def fmt_p(p):
    if p < .001: return '<0.001'
    return f'{p:.3f}'


def sig(p):
    return '***' if p < .001 else '**' if p < .01 else '*' if p < .05 else 'n.s.'


def mean_sd(x, digits=2):
    return f'{np.mean(x):.{digits}f}±{np.std(x, ddof=1):.{digits}f}'


def cohen_d(x, y):
    nx, ny = len(x), len(y)
    pooled = np.sqrt(((nx-1)*np.var(x,ddof=1)+(ny-1)*np.var(y,ddof=1))/(nx+ny-2))
    return (np.mean(x)-np.mean(y))/pooled


def table_measurement_framework():
    rows = [
        ['Anxiety', 'State anxiety', 'Over the past week, I felt nervous or uneasy.'],
        ['Digital fatigue', 'Cognitive fatigue', 'After using my phone for a while, I have difficulty concentrating.'],
        ['Digital fatigue', 'Emotional exhaustion', 'Long periods of screen time make me feel emotionally drained.'],
        ['Digital fatigue', 'Physical/visual fatigue', 'After prolonged screen viewing, I experience eye soreness or neck discomfort.'],
        ['Digital fatigue', 'Information overload/FOMO', 'When I do not check my phone, I worry about missing important information.'],
        ['Sleep and resilience', 'Sleep quality', 'Over the past week, I had difficulty falling asleep.'],
        ['Sleep and resilience', 'Resilience', 'When under stress, I can recover quickly.'],
        ['Attention and emotion', 'Attention control', 'I can focus on tasks even when distractions are around me.'],
        ['Attention and emotion', 'Negative affect', 'I feel irritable or emotionally tense.'],
        ['Behavioral indicators', 'Screen use', 'Average daily short-video viewing time in minutes.'],
        ['Behavioral indicators', 'Exercise adherence', 'Number of 10-15 minute exercise sessions completed today.'],
        ['Physiological indicators', 'HRV', 'RMSSD, SDNN, and LF/HF derived from wearable R-R interval records.'],
        ['Physiological indicators', 'Objective sleep', 'Wearable-derived total sleep time and awakenings.'],
    ]
    return pd.DataFrame(rows, columns=['Primary indicator','Secondary indicator','Example item or operationalization'])


def table_prepost(df):
    specs = [
        ('Anxiety (GAD-7)', 'gad7_t0_score', 'gad7_t2_score'),
        ('Digital fatigue', 'digital_fatigue_t0_score', 'digital_fatigue_t2_score'),
        ('Sleep quality (PSQI-Short)', 'psqi_t0_score', 'psqi_t2_score'),
        ('Resilience (BRS)', 'brs_t0_score', 'brs_t2_score'),
    ]
    rows=[]
    for outcome,t0,t2 in specs:
        for g in ['Exercise','Control']:
            sub=df[df.group==g]
            delta=sub[t2]-sub[t0]
            tstat,pval=paired_t(sub[t2],sub[t0])
            rows.append([outcome,g,len(sub),mean_sd(sub[t0]),mean_sd(sub[t2]),f'{delta.mean():.2f}',f'{tstat:.2f}',fmt_p(pval),sig(pval)])
    return pd.DataFrame(rows,columns=['Outcome','Group','N','T0 Mean±SD','T2 Mean±SD','Δ (T2−T0)','t','p','Sig'])


def table_group_interaction(df):
    specs=[('Anxiety (GAD-7)','delta_anxiety'),('Digital fatigue','delta_digital_fatigue'),('Sleep quality (PSQI-Short)','delta_sleep_quality'),('Resilience (BRS)','delta_resilience')]
    rows=[]
    for outcome,dcol in specs:
        ex=df[df.group=='Exercise'][dcol]
        co=df[df.group=='Control'][dcol]
        tstat,pval=independent_t(ex,co)
        diff=ex.mean()-co.mean()
        d=cohen_d(ex,co)
        rows.append([outcome,f'{diff:.2f}',f'{tstat:.2f}',fmt_p(pval),sig(pval),f'{d:.2f}',len(df)])
    return pd.DataFrame(rows,columns=['Outcome','Δ (Exercise−Control)','t','p','Sig','Cohen d','N'])



class OLSResult:
    def __init__(self, names, beta, se):
        self.params = dict(zip(names, beta))
        tvals = beta / se
        self.tvalues = dict(zip(names, tvals))
        self.pvalues = dict(zip(names, [2 * (1 - norm_cdf(abs(t))) for t in tvals]))
        self.bse = dict(zip(names, se))

def norm_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))

def p_from_t(t):
    # Normal approximation is accurate for these sample sizes and keeps the script dependency-light.
    return 2 * (1 - norm_cdf(abs(float(t))))

def paired_t(x, y):
    d = np.asarray(x) - np.asarray(y)
    se = d.std(ddof=1) / np.sqrt(len(d))
    t = d.mean() / se if se != 0 else 0.0
    return t, p_from_t(t)

def independent_t(x, y):
    x = np.asarray(x); y = np.asarray(y)
    se = np.sqrt(x.var(ddof=1)/len(x) + y.var(ddof=1)/len(y))
    t = (x.mean() - y.mean()) / se if se != 0 else 0.0
    return t, p_from_t(t)

def ols(y, X):
    if hasattr(X, 'values'):
        names = ['const'] + list(X.columns)
        Xm = X.values.astype(float)
    else:
        names = ['const'] + [f'x{i+1}' for i in range(np.asarray(X).shape[1])]
        Xm = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    Xc = np.column_stack([np.ones(len(y)), Xm])
    XtX_inv = np.linalg.pinv(Xc.T @ Xc)
    beta = XtX_inv @ Xc.T @ y
    resid = y - Xc @ beta
    h = np.sum((Xc @ XtX_inv) * Xc, axis=1)
    adj = resid / np.maximum(1 - h, 1e-8)
    meat = Xc.T @ (Xc * (adj ** 2)[:, None])
    cov = XtX_inv @ meat @ XtX_inv
    se = np.sqrt(np.maximum(np.diag(cov), 1e-12))
    return OLSResult(names, beta, se)


def z(x):
    return (x-np.mean(x))/np.std(x,ddof=0)


def bootstrap_mediation(df, B=3000):
    # Group coding: 1 = Exercise, 0 = Control. M and Y are improvement-coded so positive = improvement.
    work=pd.DataFrame({
        'group': df.exercise_group.values,
        'M': -df.delta_digital_fatigue.values,
        'Y': -df.delta_anxiety.values,
        'baseline_screen': z(df.baseline_screen_hours.values),
        'age': z(df.age.values),
        'female': df.female.values,
    })
    ma=ols(work.M, work[['group','baseline_screen','age','female']])
    yb=ols(work.Y, work[['group','M','baseline_screen','age','female']])
    yc=ols(work.Y, work[['group','baseline_screen','age','female']])
    a=ma.params['group']; b=yb.params['M']; cp=yb.params['group']; c=yc.params['group']
    boot_ind=[]; boot_a=[]; boot_b=[]; boot_cp=[]; boot_c=[]
    n=len(work)
    r=np.random.default_rng(SEED+1)
    for _ in range(B):
        idx=r.integers(0,n,n)
        w=work.iloc[idx]
        ma_b=ols(w.M,w[['group','baseline_screen','age','female']])
        yb_b=ols(w.Y,w[['group','M','baseline_screen','age','female']])
        yc_b=ols(w.Y,w[['group','baseline_screen','age','female']])
        aa=ma_b.params['group']; bb=yb_b.params['M']
        boot_a.append(aa); boot_b.append(bb); boot_cp.append(yb_b.params['group']); boot_c.append(yc_b.params['group']); boot_ind.append(aa*bb)
    def ci(vals):
        lo,hi=np.percentile(vals,[2.5,97.5]); return f'[{lo:.3f}, {hi:.3f}]'
    lo,hi=np.percentile(boot_ind,[2.5,97.5])
    rows=[
        ['a (Exercise → fatigue reduction)', f'{a:.3f}', fmt_p(ma.pvalues['group']), sig(ma.pvalues['group']), ci(boot_a)],
        ['b (Fatigue reduction → anxiety reduction | group)', f'{b:.3f}', fmt_p(yb.pvalues['M']), sig(yb.pvalues['M']), ci(boot_b)],
        ["c′ (Exercise → anxiety reduction | mediator)", f'{cp:.3f}', fmt_p(yb.pvalues['group']), sig(yb.pvalues['group']), ci(boot_cp)],
        ['Indirect effect (a×b)', f'{a*b:.3f}', '<0.001' if lo*hi>0 else 'n.s.', '***' if lo*hi>0 else 'n.s.', f'[{lo:.3f}, {hi:.3f}]'],
        ['Total effect (c)', f'{c:.3f}', fmt_p(yc.pvalues['group']), sig(yc.pvalues['group']), ci(boot_c)],
    ]
    return pd.DataFrame(rows,columns=['Path','Estimate','p','Sig','95% CI (Boot)'])


def table_sem_paths(df):
    # Standardized path-regression approximation.
    work=pd.DataFrame({
        'group': z(df.exercise_group.values),
        'df_improve': z(-df.delta_digital_fatigue.values),
        'anx_improve': z(-df.delta_anxiety.values),
        'sleep_improve': z(-df.delta_sleep_quality.values),
        'res_improve': z(df.delta_resilience.values),
    })
    rows=[]
    models=[
        ('Exercise → digital fatigue reduction','df_improve',['group']),
        ('Digital fatigue reduction → anxiety reduction','anx_improve',['df_improve','group']),
        ("Exercise → anxiety reduction (direct, c′)",'anx_improve',['group','df_improve','sleep_improve','res_improve']),
        ('Exercise → sleep improvement','sleep_improve',['group']),
        ('Exercise → resilience gain','res_improve',['group']),
        ('Resilience gain → anxiety reduction','anx_improve',['res_improve','group','df_improve','sleep_improve']),
        ('Sleep improvement → anxiety reduction','anx_improve',['sleep_improve','group','df_improve','res_improve']),
    ]
    for label,y,preds in models:
        m=ols(work[y],work[preds])
        pred=label.split(' → ')[0]
        key='group' if pred=='Exercise' else 'df_improve' if pred.startswith('Digital') else 'res_improve' if pred.startswith('Resilience') else 'sleep_improve'
        rows.append([label,f'{m.params[key]:.3f}',fmt_p(m.pvalues[key]),sig(m.pvalues[key])])
    return pd.DataFrame(rows,columns=['Path','Std. β','p','Sig'])


def table_hrv(df):
    specs=[('HRV-RMSSD','hrv_rmssd_t0','hrv_rmssd_t2'),('HRV-SDNN','hrv_sdnn_t0','hrv_sdnn_t2'),('HRV-LF/HF','hrv_lfhf_t0','hrv_lfhf_t2')]
    rows=[]
    for outcome,t0,t2 in specs:
        for g in ['Exercise','Control']:
            sub=df[df.group==g]
            delta=sub[t2]-sub[t0]
            tstat,pval=paired_t(sub[t2],sub[t0])
            rows.append([outcome,g,len(sub),mean_sd(sub[t0],2),mean_sd(sub[t2],2),f'{delta.mean():.2f}',f'{tstat:.2f}',fmt_p(pval),sig(pval)])
    return pd.DataFrame(rows,columns=['Outcome','Group','N','T0 Mean±SD','T2 Mean±SD','Δ (T2−T0)','t','p','Sig'])


def table_stage(df):
    specs=[('Δ Anxiety (GAD-7)','delta_anxiety'),('Δ Digital fatigue','delta_digital_fatigue'),('Δ Sleep quality (PSQI-Short)','delta_sleep_quality'),('Δ Resilience (BRS)','delta_resilience')]
    rows=[]
    for outcome,dcol in specs:
        for st in ['Middle school','High school','College']:
            sub=df[df.stage==st]
            ex=sub[sub.group=='Exercise'][dcol]
            co=sub[sub.group=='Control'][dcol]
            tstat,pval=independent_t(ex,co)
            rows.append([outcome,st,len(ex),len(co),mean_sd(ex,2),mean_sd(co,2),f'{(ex.mean()-co.mean()):.2f}',fmt_p(pval),sig(pval)])
    return pd.DataFrame(rows,columns=['Outcome','Stage','N_exercise','N_control','Δ_exercise Mean±SD','Δ_control Mean±SD','Diff (Ex−Ctrl)','p','Sig'])


def table_summary(df):
    return pd.DataFrame({
        'Metric':['Total N','Exercise group','Control group','Female (%)','Age range','Mean age','Middle school','High school','College'],
        'Value':[len(df), int((df.group=='Exercise').sum()), int((df.group=='Control').sum()), f'{df.female.mean()*100:.1f}%', f'{df.age.min():.0f}-{df.age.max():.0f}', f'{df.age.mean():.2f}±{df.age.std(ddof=1):.2f}', int((df.stage=='Middle school').sum()), int((df.stage=='High school').sum()), int((df.stage=='College').sum())]
    })


def write_tables(tables):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(TABLES_FILE, engine='openpyxl') as writer:
        for name,tab in tables.items():
            tab.to_excel(writer, sheet_name=name[:31], index=False)
    wb = Workbook()
    wb.remove(wb.active)
    thin=Side(style='thin', color='BFBFBF')
    thick=Side(style='medium', color='000000')
    fill=PatternFill('solid', fgColor='F2F2F2')
    for name,tab in tables.items():
        ws=wb.create_sheet(name[:31])
        for r_idx,row in enumerate(dataframe_to_rows(tab,index=False,header=True),1):
            ws.append(row)
            for c_idx,_ in enumerate(row,1):
                cell=ws.cell(r_idx,c_idx)
                cell.alignment=Alignment(horizontal='center' if r_idx==1 else 'left', vertical='center', wrap_text=True)
                if r_idx==1:
                    cell.font=Font(bold=True)
                    cell.fill=fill
                    cell.border=Border(top=thick,bottom=thick)
                else:
                    cell.border=Border(bottom=thin)
        for col in ws.columns:
            width=max(len(str(c.value)) if c.value is not None else 0 for c in col)
            ws.column_dimensions[col[0].column_letter].width=min(max(width+2,12),38)
    wb.save(TABLES_FILE)


def main():
    raw=load_or_create_raw()
    df=add_change_scores(raw)
    processed_cols=[c for c in df.columns if not '_item' in c]
    df[processed_cols].to_excel(PROCESSED_FILE,index=False)
    tables={
        'Table 1 Framework': table_measurement_framework(),
        'Sample Summary': table_summary(df),
        'Table 2 PrePost': table_prepost(df),
        'Table 3 GroupTime': table_group_interaction(df),
        'Table 4 Mediation': bootstrap_mediation(df,3000),
        'Table 5 SEM Paths': table_sem_paths(df),
        'Table 6 HRV': table_hrv(df),
        'Table 7 Stage': table_stage(df),
    }
    write_tables(tables)
    print(f'Raw item-level data: {RAW_FILE}')
    print(f'Processed scores: {PROCESSED_FILE}')
    print(f'Final tables: {TABLES_FILE}')
    for name,tab in tables.items():
        print('\n'+name)
        print(tab.to_string(index=False))

if __name__=='__main__':
    main()
