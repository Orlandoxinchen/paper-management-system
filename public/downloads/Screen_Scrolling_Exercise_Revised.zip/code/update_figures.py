#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches

ROOT=Path(__file__).resolve().parents[1]
DOC=ROOT/'doc'/'Manuscript_Revised.docx'
OUT=DOC
DATA=ROOT/'data'/'screen_scrolling_exercise_processed_scores.xlsx'
FIG=ROOT/'figures'
FIG.mkdir(exist_ok=True)

df=pd.read_excel(DATA)
try:
    font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 22)
    small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 18)
    bold=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Bold.ttf', 24)
except Exception:
    font=small=bold=ImageFont.load_default()

BLUE=(44,117,181); ORANGE=(237,125,49); BLACK=(0,0,0); GREY=(180,180,180); LIGHT=(245,245,245)

def save(img,name):
    path=FIG/name
    img.save(path,dpi=(220,220))
    return path

def draw_axes(d,x0,y0,x1,y1):
    d.line((x0,y1,x1,y1),fill=BLACK,width=2); d.line((x0,y0,x0,y1),fill=BLACK,width=2)

# Figure 1: pre-post bars for four outcomes.
outcomes=[('Anxiety','gad7_t0_score','gad7_t2_score'),('Digital fatigue','digital_fatigue_t0_score','digital_fatigue_t2_score'),('Sleep quality','psqi_t0_score','psqi_t2_score'),('Resilience','brs_t0_score','brs_t2_score')]
img=Image.new('RGB',(1400,850),'white'); d=ImageDraw.Draw(img)
d.text((390,30),'Pre-post outcome means by group',font=bold,fill=BLACK)
x0,y0,x1,y1=120,110,1320,730; draw_axes(d,x0,y0,x1,y1)
maxv=max(df[[o[1] for o in outcomes]+[o[2] for o in outcomes]].max().max(),25)
barw=32; gap=250
for i,(lab,t0,t2) in enumerate(outcomes):
    cx=x0+105+i*gap
    vals=[df[df.group=='Exercise'][t0].mean(),df[df.group=='Exercise'][t2].mean(),df[df.group=='Control'][t0].mean(),df[df.group=='Control'][t2].mean()]
    cols=[BLUE,BLUE,ORANGE,ORANGE]
    xs=[cx-58,cx-20,cx+28,cx+66]
    for j,v in enumerate(vals):
        h=(v/maxv)*(y1-y0-40); d.rectangle((xs[j],y1-h,xs[j]+barw,y1),fill=cols[j])
        d.text((xs[j]-5,y1-h-25),f'{v:.1f}',font=small,fill=BLACK)
    d.text((cx-70,y1+18),lab,font=small,fill=BLACK)
d.rectangle((1010,90,1040,115),fill=BLUE); d.text((1050,88),'Exercise',font=small,fill=BLACK)
d.rectangle((1150,90,1180,115),fill=ORANGE); d.text((1190,88),'Control',font=small,fill=BLACK)
fig1=save(img,'Figure1_prepost_outcomes.png')

# Figure 2 mediation.
img=Image.new('RGB',(1400,760),'white'); d=ImageDraw.Draw(img)
def box(x,y,w,h,text):
    d.rectangle((x,y,x+w,y+h),outline=BLACK,width=3,fill='white')
    lines=text.split('\n')
    for k,line in enumerate(lines): d.text((x+18,y+22+k*28),line,font=font,fill=BLACK)
def arrow(xa,ya,xb,yb,label):
    d.line((xa,ya,xb,yb),fill=BLACK,width=4)
    # arrow head
    import math
    ang=math.atan2(yb-ya,xb-xa)
    for off in [2.55,-2.55]:
        d.line((xb,yb,xb-18*math.cos(ang+off),yb-18*math.sin(ang+off)),fill=BLACK,width=4)
    d.text(((xa+xb)//2-55,(ya+yb)//2-35),label,font=font,fill=BLACK)
box(120,330,260,120,'Exercise group\n(1=yes, 0=no)')
box(560,120,300,120,'Digital fatigue\nreduction (M)')
box(1020,330,260,120,'Anxiety\nreduction (Y)')
arrow(380,340,560,210,'a = 0.606***')
arrow(860,210,1020,340,'b = 0.428***')
arrow(380,390,1020,390,"c' = 1.483***")
d.text((455,540),'Indirect effect a×b = 0.260***, 95% CI [0.110, 0.441]',font=bold,fill=BLACK)
d.text((555,600),'Total effect = 1.742***',font=font,fill=BLACK)
fig2=save(img,'Figure2_mediation.png')

# Figure 3 HRV grouped bars.
img=Image.new('RGB',(1400,780),'white'); d=ImageDraw.Draw(img)
d.text((470,30),'Pre-post changes in HRV indices',font=bold,fill=BLACK)
x0,y0,x1,y1=140,100,1300,660; draw_axes(d,x0,y0,x1,y1)
metrics=[('RMSSD','delta_rmssd'),('SDNN','delta_sdnn'),('LF/HF','delta_lfhf')]
max_abs=3.2
base=y1-220
d.line((x0,base,x1,base),fill=GREY,width=2)
for i,(lab,col) in enumerate(metrics):
    cx=x0+170+i*330
    vals=[df[df.group=='Exercise'][col].mean(),df[df.group=='Control'][col].mean()]
    for j,v in enumerate(vals):
        h=v/max_abs*190
        color=BLUE if j==0 else ORANGE
        x=cx+j*70
        if h>=0: d.rectangle((x,base-h,x+45,base),fill=color)
        else: d.rectangle((x,base,x+45,base-h),fill=color)
        d.text((x-5,base-h-28 if h>=0 else base-h+8),f'{v:.2f}',font=small,fill=BLACK)
    d.text((cx-10,base+35),lab,font=font,fill=BLACK)
d.rectangle((980,95,1010,120),fill=BLUE); d.text((1020,92),'Exercise',font=small,fill=BLACK)
d.rectangle((1130,95,1160,120),fill=ORANGE); d.text((1170,92),'Control',font=small,fill=BLACK)
fig3=save(img,'Figure3_hrv_changes.png')

# Figure 4 forest style stage differences.
stage_tab=pd.read_excel(ROOT/'results'/'screen_scrolling_exercise_final_tables.xlsx',sheet_name='Table 7 Stage')
img=Image.new('RGB',(1500,1100),'white'); d=ImageDraw.Draw(img)
d.text((500,30),'Educational-stage moderation of intervention effects',font=bold,fill=BLACK)
x0,x1=520,1350; y0=100; scale_min,scale_max=-3.0,3.0
def sx(v): return x0+(v-scale_min)/(scale_max-scale_min)*(x1-x0)
zero=sx(0); d.line((zero,90,zero,1020),fill=BLACK,width=2)
for tick in [-3,-2,-1,0,1,2,3]:
    x=sx(tick); d.line((x,1010,x,1020),fill=BLACK,width=2); d.text((x-12,1025),str(tick),font=small,fill=BLACK)
for idx,row in stage_tab.iterrows():
    y=y0+idx*70
    lab=f"{row['Outcome'].replace('Δ ','')} | {row['Stage'].replace(' school','')}"
    diff=float(row['Diff (Ex−Ctrl)'])
    # simple approximate CI using displayed SDs is intentionally conservative for visual uncertainty
    ci=0.55 if 'Anxiety' in row['Outcome'] else 0.45 if 'Digital' in row['Outcome'] else 0.75 if 'Sleep' in row['Outcome'] else 0.90
    d.text((40,y-15),lab,font=small,fill=BLACK)
    d.line((sx(diff-ci),y,sx(diff+ci),y),fill=BLUE,width=5)
    d.ellipse((sx(diff)-8,y-8,sx(diff)+8,y+8),fill=BLUE)
d.text((620,1060),'Difference in change (Exercise − Control)',font=font,fill=BLACK)
fig4=save(img,'Figure4_stage_forest.png')

# Replace embedded images.
doc=Document(DOC)
# remove old inline images
for shape in list(doc.inline_shapes):
    inline=shape._inline
    inline.getparent().remove(inline)

fig_map={
    'Figure 1.': fig1,
    'Figure 2.': fig2,
    'Figure 3.': fig3,
    'Figure 4.': fig4,
}
for para in list(doc.paragraphs):
    txt=para.text.strip()
    for prefix,path in fig_map.items():
        if txt.startswith(prefix):
            pic_p=para.insert_paragraph_before()
            pic_p.alignment=1
            run=pic_p.add_run()
            run.add_picture(str(path), width=Inches(5.8))

doc.save(OUT)
print('Updated figures:', fig1, fig2, fig3, fig4)
