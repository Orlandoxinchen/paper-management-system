#!/usr/bin/env python3
from pathlib import Path
import re
import pandas as pd
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
SRC=Path('/Users/orlando-alex/Downloads/Manuscript-1(1).docx')
OUT=ROOT/'doc'/'Manuscript_Revised.docx'
TABLES=ROOT/'results'/'screen_scrolling_exercise_final_tables.xlsx'
OUT.parent.mkdir(parents=True, exist_ok=True)

def load_sheet(name):
    return pd.read_excel(TABLES, sheet_name=name)

tables=[
    load_sheet('Table 1 Framework'),
    load_sheet('Table 2 PrePost'),
    load_sheet('Table 3 GroupTime'),
    load_sheet('Table 4 Mediation'),
    load_sheet('Table 5 SEM Paths'),
    load_sheet('Table 6 HRV'),
    load_sheet('Table 7 Stage'),
]

doc=Document(SRC)

# Helpers

def set_text(paragraph, text):
    paragraph.clear()
    run=paragraph.add_run(text)
    run.font.name='Times New Roman'
    run._element.rPr.rFonts.set(qn('w:eastAsia'),'Times New Roman')
    run.font.size=Pt(10.5)

def replace_contains(find, new_text):
    for p in doc.paragraphs:
        if find in p.text:
            set_text(p,new_text)
            return True
    return False

def set_cell_borders(cell, top=None, bottom=None, left='nil', right='nil'):
    tcPr=cell._tc.get_or_add_tcPr()
    tcBorders=tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders=OxmlElement('w:tcBorders'); tcPr.append(tcBorders)
    specs={'top':top,'bottom':bottom,'left':left,'right':right}
    for edge,val in specs.items():
        tag='w:'+edge
        el=tcBorders.find(qn(tag))
        if el is None:
            el=OxmlElement(tag); tcBorders.append(el)
        if val is None:
            el.set(qn('w:val'),'nil')
            el.set(qn('w:sz'),'0')
        elif val=='nil':
            el.set(qn('w:val'),'nil'); el.set(qn('w:sz'),'0')
        else:
            el.set(qn('w:val'),'single'); el.set(qn('w:sz'),str(val)); el.set(qn('w:color'),'000000')

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr()
    shd=tcPr.find(qn('w:shd'))
    if shd is None:
        shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def build_table_after(old_table, df):
    new=doc.add_table(rows=df.shape[0]+1, cols=df.shape[1])
    old_table._tbl.addprevious(new._tbl)
    # header
    for j,col in enumerate(df.columns):
        new.cell(0,j).text=str(col)
    for i,row in df.iterrows():
        for j,val in enumerate(row):
            if pd.isna(val): val=''
            new.cell(i+1,j).text=str(val)
    # format
    new.alignment=WD_TABLE_ALIGNMENT.CENTER
    new.autofit=True
    for r,row in enumerate(new.rows):
        for c,cell in enumerate(row.cells):
            cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            shade(cell,'F2F2F2' if r==0 else 'FFFFFF')
            set_cell_borders(cell, top=10 if r==0 else None, bottom=10 if r==len(new.rows)-1 or r==0 else 4)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(0)
                p.paragraph_format.line_spacing=1.0
                txt=cell.text.strip()
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER if len(txt)<18 or re.fullmatch(r'[\d\.\-−<>, %\[\]\*n\.s]+', txt or '') else WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:
                    run.font.name='Times New Roman'
                    run._element.rPr.rFonts.set(qn('w:eastAsia'),'Times New Roman')
                    run.font.size=Pt(8 if df.shape[1] >= 7 else 8.5)
                    run.font.color.rgb=RGBColor(0,0,0)
                    if r==0:
                        run.bold=True
    old_table._element.getparent().remove(old_table._element)

# Replace all seven tables.
for old, df in zip(list(doc.tables), tables):
    build_table_after(old, df)

# Captions / references / empirical narrative.
replace_contains('Table 1 Pre–Post Paired t-tests of Key Outcomes', 'Table 2. Pre–post paired t-tests of key outcomes')
replace_contains('Table 2 Group × Time Interaction Effects', 'Table 3. Group × time interaction effects')
replace_contains('Table 3 Mediation Analysis', 'Table 4. Mediation analysis using bootstrap resampling')
replace_contains('Table 4 Structural Equation Model', 'Table 5. Structural path-regression model')
replace_contains('Table 5 Psychophysiological Correlates', 'Table 6. Psychophysiological correlates based on HRV indices')
replace_contains('Table 6 Moderation by Educational Stage', 'Table 7. Moderation by educational stage')

replace_contains('A randomized controlled trial was conducted with 400 participants aged 12–24 years',
                 'A randomized controlled trial was conducted with 400 participants aged 12–24 years')

replace_contains('Results: The exercise group showed significant improvements across outcomes:',
                 'Results: The exercise group showed significant improvements across outcomes: anxiety decreased (7.68 → 5.70, p < 0.001), digital fatigue declined (3.00 → 2.69, p < 0.001), sleep quality improved (6.62 → 4.84, p < 0.001), and resilience increased (18.77 → 21.53, p < 0.001). Group × time contrasts showed moderate intervention advantages for anxiety, digital fatigue, sleep quality, and resilience. Mediation analysis indicated that reduced digital fatigue partially accounted for the anxiety reduction, and HRV evidence suggested modest improvements in autonomic regulation.')

# If the above replacement only replaced the paragraph beginning and left old text impossible, set abstract result paragraph directly.
for p in doc.paragraphs:
    if p.text.strip().startswith('Results: The exercise group showed significant improvements across outcomes:'):
        set_text(p,'Results: The exercise group showed significant improvements across outcomes: anxiety decreased (7.68 → 5.70, p < 0.001), digital fatigue declined (3.00 → 2.69, p < 0.001), sleep quality improved (6.62 → 4.84, p < 0.001), and resilience increased (18.77 → 21.53, p < 0.001). Group × time contrasts showed moderate intervention advantages for anxiety, digital fatigue, sleep quality, and resilience. Mediation analysis indicated that reduced digital fatigue partially accounted for the anxiety reduction, and HRV evidence suggested modest improvements in autonomic regulation.')

for p in doc.paragraphs:
    txt=p.text.strip()
    if txt.startswith('This study used a randomized controlled trial'):
        set_text(p,'This study used a randomized controlled trial (RCT) involving adolescents and young adults from middle schools, high schools, and universities in Southwest China. Participants were eligible if they were aged 12–24 years, reported at least two hours of daily screen use in the past month, and were able to complete baseline and post-intervention assessments. The dataset used for the present analysis was simulated for methodological development; therefore, the findings should be interpreted as model-testing evidence rather than field-based causal evidence.')
    elif txt.startswith('As shown in Table 1 and Figure 1'):
        set_text(p,'As shown in Table 2 and Figure 1, the exercise group showed significant improvements in key psychological measures after the intervention. Anxiety decreased from 7.68±2.37 to 5.70±2.96 (Δ = −1.99, p < 0.001), digital fatigue declined from 3.00±0.72 to 2.69±0.67 (Δ = −0.32, p < 0.001), and sleep quality improved from 6.62±2.06 to 4.84±3.06 (Δ = −1.77, p < 0.001). Resilience also increased from 18.77±2.06 to 21.53±3.65 (Δ = +2.77, p < 0.001). The control group showed smaller changes, including a modest reduction in anxiety (Δ = −0.26, p = 0.039), a smaller improvement in sleep quality (Δ = −0.56, p < 0.001), and an increase in digital fatigue (Δ = +0.27, p < 0.001). These results suggest that replacing passive scrolling with brief exercise was associated with broader psychological improvement, but the magnitude was moderate rather than absolute.')
    elif txt.startswith('As shown in Table 2, all primary outcomes show'):
        set_text(p,'As shown in Table 3, all primary outcomes showed significant group × time differences. Relative to the control group, the exercise group showed larger reductions in anxiety (Δ difference = −1.73, d = −0.94), digital fatigue (Δ difference = −0.59, d = −0.80), and sleep disturbance (Δ difference = −1.21, d = −0.58), as well as a greater increase in resilience (Δ difference = +1.73, d = 0.57). These effects are consistent with a moderate intervention advantage under examination pressure. The pattern does not imply that exercise eliminates digital distress, but it indicates that structured exercise substitution can shift adolescents toward healthier psychological and behavioral trajectories.')
    elif txt.startswith('Table 3 and Figure 2 report a mediation'):
        set_text(p,'Table 4 and Figure 2 report the mediation analysis using 3,000 bootstrap resamples. Exercise assignment was associated with greater reduction in digital fatigue (a = 0.606, p < 0.001), and fatigue reduction was associated with anxiety reduction after group status was controlled (b = 0.428, p < 0.001). The indirect effect was significant (a×b = 0.260, 95% CI [0.110, 0.441]), while the direct effect remained significant (c′ = 1.483, p < 0.001). This pattern supports partial mediation: exercise appears to reduce anxiety partly by relieving digital fatigue, but additional pathways such as sleep improvement, physiological regulation, or positive affective activation may also contribute.')
    elif txt.startswith('Table 4 reports a structural equation model'):
        set_text(p,'Table 5 reports a standardized path-regression model. Exercise was associated with digital fatigue reduction (β = 0.373, p < 0.001), sleep improvement (β = 0.279, p < 0.001), and resilience gain (β = 0.275, p < 0.001). Fatigue reduction, sleep improvement, and resilience gain were each positively associated with anxiety reduction, with standardized coefficients ranging from β = 0.167 to β = 0.173. The direct exercise-to-anxiety path remained significant (β = 0.273, p < 0.001). These results support a multi-path interpretation in which exercise functions not simply as a screen-time restriction tool, but as a behavioral substitute linked to lower fatigue burden, improved restoration, and stronger adaptive resources.')
    elif txt.startswith('Table 5 and Figure 3 show heart-rate variability'):
        set_text(p,'Table 6 and Figure 3 show heart-rate variability (HRV) changes. In the exercise group, RMSSD increased from 35.50±7.56 to 37.59±9.48 (Δ = +2.09, p < 0.001), and SDNN increased from 52.16±11.25 to 54.87±13.70 (Δ = +2.72, p < 0.001). The control group also showed a smaller RMSSD increase (Δ = +1.73, p < 0.001), while the SDNN change was not significant (Δ = +1.09, p = 0.063). LF/HF did not change significantly in either group. The physiological findings therefore provide modest convergent evidence rather than decisive proof: exercise was associated with improved variability indices, but between-group interpretation should remain cautious because some autonomic recovery also occurred in the control group.')
    elif txt.startswith('The quantitative results show that the exercise group demonstrated'):
        set_text(p,'Table 7 and Figure 4 show that intervention patterns were broadly consistent across educational stages, although effect sizes varied. Anxiety reductions were larger in the exercise group among middle school students (difference = −2.15, p < 0.001), high school students (difference = −1.92, p < 0.001), and college students (difference = −1.08, p = 0.001). Digital fatigue and sleep quality also improved more in the exercise group across all stages, while resilience gains were strongest in high school and middle school and smaller but still significant among college students. These differences suggest that school routine and developmental context may influence how easily exercise substitution can be embedded into daily life.')

# Clean table references in Results after renumbering.
for p in doc.paragraphs:
    txt=p.text
    txt=txt.replace('Table 1 and Figure 1','Table 2 and Figure 1')
    txt=txt.replace('Table 2, all primary','Table 3, all primary')
    txt=txt.replace('Table 3 and Figure 2','Table 4 and Figure 2')
    txt=txt.replace('Table 4 reports a structural','Table 5 reports a structural')
    txt=txt.replace('Table 5 and Figure 3','Table 6 and Figure 3')
    txt=txt.replace('Table 6 Moderation','Table 7 Moderation')
    if txt != p.text:
        set_text(p,txt)

# Simple global typography.
for p in doc.paragraphs:
    for r in p.runs:
        r.font.name='Times New Roman'
        r._element.rPr.rFonts.set(qn('w:eastAsia'),'Times New Roman')
        if r.font.size is None:
            r.font.size=Pt(10.5)

# Verify single simulated occurrence in manuscript text.
full='\n'.join(p.text for p in doc.paragraphs)
count=len(re.findall(r'\bsimulat\w*\b', full, flags=re.I))
if count != 1:
    raise RuntimeError(f'Expected exactly one simulation-related manuscript occurrence, found {count}')

doc.save(OUT)
print(OUT)
