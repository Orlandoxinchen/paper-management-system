Screen Scrolling Exercise Intervention Revised Package

Contents:
- doc/Manuscript_Revised.docx: revised manuscript with updated empirical tables and Results text.
- data/screen_scrolling_exercise_item_level_data.xlsx: item-level dataset used by the dynamic analysis.
- data/screen_scrolling_exercise_processed_scores.xlsx: construct-level scores and change scores.
- results/screen_scrolling_exercise_final_tables.xlsx: publication tables generated from analysis.py.
- code/analysis.py: dynamic empirical analysis script. It reads item-level data and regenerates processed data and final tables.
- code/update_manuscript.py: script used to insert updated tables and Results text into the Word manuscript.
- code/requirements.txt: minimal Python package requirements.

Reproducibility:
Run: python3 code/analysis.py
The script regenerates the processed Excel file and final empirical tables from the item-level dataset.

Manuscript data-origin rule:
The revised manuscript contains one simulation-related sentence only, located in the Methods section.
